--##################################################
-- Jaipur Metro Station Case Study :-
--##########################################

create database jp_metro_db ; 

use jp_metro_db ;

-- passenger table 

create table passengers (
pass_id int primary key ,
pass_name varchar(25),
pass_age int 
);
-- metro table 

create table metro(
met_id int primary key ,
met_no int ,
met_line varchar(10)
);
-- station table 

create table stations(
st_id int primary key ,
 st_name varchar(20));
 
 -- booking table
 
create table bookings (
ticket_id int primary key ,
pnr bigint , 
pass_id int ,
departure_station int ,
arrival_station int,
met_id int ,
fare float,
journey_date date ,
constraint fk_m_pass_id
 foreign key (met_id) references metro(met_id),
constraint fk_b_pass_id
 foreign key (pass_id) references passengers(pass_id),
constraint fk_b_dp_st foreign key (departure_station)
 references stations(st_id),
constraint fk_b_arr_st foreign key(arrival_station)
 references stations(st_id));

alter table bookings modify column journey_date DATE;
 
-- checking that all tables load properly ; 
select * from passengers;
select * from metro ; 
select * from stations;
select * from bookings;

-- trial query'

select * from passengers order by pass_age desc ;
select pass_id , journey_date from bookings where journey_date = "2025-06-23" ;

-- questions
-- Q1. Show all bookings with passenger names and metro lines
 SELECT 
    b.ticket_id,
    p.pass_name,
    s1.st_name AS departure_station,
    s2.st_name AS arrival_station,
    m.met_line,
    b.fare,
    b.journey_date
FROM bookings b
JOIN passengers p ON b.pass_id = p.pass_id
JOIN stations s1 ON b.departure_station = s1.st_id
JOIN stations s2 ON b.arrival_station = s2.st_id
JOIN metro m ON b.met_id = m.met_id;

-- Q2.Number of bookings per station 
SELECT 
    s.st_name AS station_name,
    COUNT(*) AS total_bookings
FROM bookings b
JOIN stations s ON b.departure_station = s.st_id
GROUP BY b.departure_station;

-- Q3.  Bookings per metro line
SELECT 
    m.met_line,
    COUNT(*) AS total_bookings
FROM bookings b
JOIN metro m ON b.met_id = m.met_id
GROUP BY b.met_id;

-- Q4. Total fare collected per metro line
SELECT 
    m.met_line,
    SUM(b.fare) AS total_fare
FROM bookings b
JOIN metro m ON b.met_id = m.met_id
GROUP BY b.met_id;

-- Q5.Count of bookings per day
SELECT journey_date, COUNT(*) AS total_bookings
FROM bookings
GROUP BY journey_date
ORDER BY journey_date DESC;

-- Q6. Number of passengers boarded and deboarded station-wise

SELECT 
    s.st_id,
    s.st_name,
    COALESCE(boarded.total_boarded, 0) AS boarded_count,
    COALESCE(deboarded.total_deboarded, 0) AS deboarded_count
FROM stations s
LEFT JOIN (
    SELECT departure_station AS st_id, COUNT(*) AS total_boarded
    FROM bookings
    GROUP BY departure_station
) boarded ON s.st_id = boarded.st_id
LEFT JOIN (
    SELECT arrival_station AS st_id, COUNT(*) AS total_deboarded
    FROM bookings
    GROUP BY arrival_station
) deboarded ON s.st_id = deboarded.st_id
ORDER BY s.st_id;

-- INSIGHTS 

-- Q7. . Most Frequent Travelers
SELECT p.pass_id, p.pass_name, COUNT(*) AS total_bookings
FROM bookings b
JOIN passengers p ON b.pass_id = p.pass_id
GROUP BY p.pass_id
ORDER BY total_bookings DESC
LIMIT 5;

 -- Q8. Average Fare Paid by Each Passenger
SELECT p.pass_id, p.pass_name, ROUND(AVG(b.fare), 2) AS avg_fare
FROM bookings b
JOIN passengers p ON b.pass_id = p.pass_id
GROUP BY p.pass_id;

 -- Q9 Busiest Station (Boarding + Deboarding Combined)
SELECT s.st_id, s.st_name,
       COALESCE(b1.boarded, 0) + COALESCE(b2.deboarded, 0) AS total_traffic
FROM stations s
LEFT JOIN (
    SELECT departure_station AS st_id, COUNT(*) AS boarded
    FROM bookings GROUP BY departure_station
) b1 ON s.st_id = b1.st_id
LEFT JOIN (
    SELECT arrival_station AS st_id, COUNT(*) AS deboarded
    FROM bookings GROUP BY arrival_station
) b2 ON s.st_id = b2.st_id
ORDER BY total_traffic DESC;

-- PEAK TRAVLE DAY AND DATE BOOKINGS

-- Q10. DALIY BOOKINGS 
SELECT journey_date, COUNT(*) AS bookings
FROM bookings
GROUP BY journey_date
ORDER BY journey_date;

-- Q11. Peak Traveling Days 
SELECT journey_date, COUNT(*) AS total
FROM bookings
GROUP BY journey_date
ORDER BY total DESC
LIMIT 5;







 
